create function funcgerarsenha(codemail character varying) returns character varying
    language plpgsql
as
$$
/*

Criador: Siqueira, Robson.

Data: 05/08/2011.

DESCRIÇÃO: 

  A partir de um email válido, gera uma senha de 10 caracteres com letras maiúsculas e números.

  Se o email estiver incorreto, gera uma exceção.

  A senha já é armazenada no BD com criptografia MD5.

*/

DECLARE

  codPessoa INTEGER;

  codSenha VARCHAR(100);

BEGIN

  SELECT id_pessoa INTO codPessoa

  FROM pessoa

  WHERE email = codEmail;

  IF NOT FOUND THEN

    RAISE EXCEPTION 'Email Inválido';

  END IF;

  codSenha = (((random() * (100000000000000)::double precision))::bigint)::character varying;

  SELECT UPPER(md5(codSenha)::varchar(10)) INTO codSenha;

  UPDATE pessoa 

  SET senha = md5(codSenha)

  WHERE id_pessoa = codPessoa;

  RETURN codSenha;

END;

$$;

alter function funcgerarsenha(varchar) owner to postgres;

