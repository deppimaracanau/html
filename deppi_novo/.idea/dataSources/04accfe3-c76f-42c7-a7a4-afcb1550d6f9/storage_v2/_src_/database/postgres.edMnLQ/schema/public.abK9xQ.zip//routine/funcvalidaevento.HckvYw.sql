create function funcvalidaevento() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.validada = 'T' THEN

    NEW.data_validacao = now();

  END IF;

  RETURN NEW;

END;

$$;

alter function funcvalidaevento() owner to postgres;

