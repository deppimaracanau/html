create function funcvalidausuario() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.cadastro_validado = 'T' THEN

--    SELECT now() INTO NEW.data_validacao_cadastro;

    NEW.data_validacao_cadastro = now();

  END IF;

  RETURN NEW;

END;

$$;

alter function funcvalidausuario() owner to postgres;

