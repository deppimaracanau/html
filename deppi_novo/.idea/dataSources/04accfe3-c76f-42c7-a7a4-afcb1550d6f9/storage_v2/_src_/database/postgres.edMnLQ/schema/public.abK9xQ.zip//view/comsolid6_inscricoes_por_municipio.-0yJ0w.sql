create view comsolid6_inscricoes_por_municipio(nome_municipio, count) as
SELECT m.nome_municipio,
       count(*) AS count
FROM conferencia_participante ep,
     municipio m
WHERE ep.id_conferencia = 4
  AND ep.id_municipio = m.id_municipio
GROUP BY m.nome_municipio
ORDER BY m.nome_municipio;

alter table comsolid6_inscricoes_por_municipio
    owner to postgres;

